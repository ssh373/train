from isaaclab.utils import configclass
from booster_train.tasks.manager_based.locomotion.agents.rsl_rl_ppo_cfg import BasePPORunnerCfg


@configclass
class PPORunnerCfg(BasePPORunnerCfg):
    max_iterations = 50000
    save_interval = 200
    experiment_name = "k1_walk_002"
    logger = "wandb"