"""MDP terms for contact-free K1 target alignment.

The task ends at a stable pre-kick alignment.  It never rewards or requires a
ball launch; the next behavior can therefore hand the state to ``kick_001``.
"""

from __future__ import annotations

import math

import torch

from isaaclab.assets import Articulation, RigidObject
from isaaclab.envs import ManagerBasedEnv, ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import quat_apply_inverse, yaw_quat

# Keep the locomotion/kick observation and regularization terms available under
# the same names used by kick_001.  Task-specific terms below are independent.
from booster_train.tasks.manager_based.kick.mdp import *  # noqa: F401,F403,E402
from booster_train.tasks.manager_based.kick.mdp import kick_mdp as _kick_mdp


def _robot(env: ManagerBasedEnv, asset_cfg: SceneEntityCfg) -> Articulation:
    return env.scene[asset_cfg.name]


def _ball(env: ManagerBasedEnv, ball_cfg: SceneEntityCfg) -> RigidObject:
    return env.scene[ball_cfg.name]


def _target_direction_w(env: ManagerBasedEnv) -> torch.Tensor:
    if hasattr(env, "_adjust_target_w"):
        target_w = env._adjust_target_w
    else:
        target_w = env.scene.env_origins[:, :2] + torch.tensor(
            (4.0, 0.0), device=env.device
        )
    ball = env.scene["ball"]
    direction = target_w - ball.data.root_pos_w[:, :2]
    return direction / torch.norm(direction, dim=1, keepdim=True).clamp_min(1.0e-6)


def ball_position_camera_b(
    env: ManagerBasedEnv,
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
    base_noise_std: float = 0.03,
    distance_noise_ratio: float = 0.02,
    dropout_rate_per_s: float = 0.50,
    dropout_duration_range: tuple[float, float] = (0.08, 0.30),
) -> torch.Tensor:
    """Use the same camera-like ball observation contract as kick_001."""

    return _kick_mdp.camera_ball_pos_b(
        env,
        ball_cfg=ball_cfg,
        base_noise_std=base_noise_std,
        distance_noise_ratio=distance_noise_ratio,
        dropout_rate_per_s=dropout_rate_per_s,
        dropout_duration_range=dropout_duration_range,
    )


def target_direction_b(env: ManagerBasedEnv) -> torch.Tensor:
    """Unit vector from the ball to the kick target in the robot yaw frame."""

    robot = env.scene["robot"]
    direction_w = torch.cat(
        (_target_direction_w(env), torch.zeros(env.num_envs, 1, device=env.device)), dim=1
    )
    return quat_apply_inverse(yaw_quat(robot.data.root_quat_w), direction_w)[:, :2]


def ball_velocity_b(
    env: ManagerBasedEnv,
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    """Exact ball-relative velocity for the privileged critic."""

    robot = _robot(env, robot_cfg)
    ball = _ball(env, ball_cfg)
    velocity_w = ball.data.root_lin_vel_w - robot.data.root_lin_vel_w
    return quat_apply_inverse(yaw_quat(robot.data.root_quat_w), velocity_w)[:, :2]


def ball_speed(env: ManagerBasedEnv, ball_cfg: SceneEntityCfg = SceneEntityCfg("ball")) -> torch.Tensor:
    ball = _ball(env, ball_cfg)
    return torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1)


def ball_displacement(env: ManagerBasedEnv, ball_cfg: SceneEntityCfg = SceneEntityCfg("ball")) -> torch.Tensor:
    ball = _ball(env, ball_cfg)
    start = getattr(env, "_adjust_ball_start_xy", ball.data.root_pos_w[:, :2])
    return torch.norm(ball.data.root_pos_w[:, :2] - start, dim=1)


def task_phase(env: ManagerBasedEnv, value: float = 0.0) -> torch.Tensor:
    """Reserved phase slot for the future unified adjust->kick policy."""

    return torch.full((env.num_envs, 1), value, device=env.device)


def _stage_index(
    env: ManagerBasedEnv,
    stage_steps: tuple[int, ...],
    number_of_stages: int,
    curriculum_stage: int,
) -> int:
    if curriculum_stage >= 0:
        return min(curriculum_stage, number_of_stages - 1)
    step = int(getattr(env, "common_step_counter", 0))
    return min(sum(step >= threshold for threshold in stage_steps), number_of_stages - 1)


def reset_adjust_scenario(
    env: ManagerBasedEnv,
    env_ids: torch.Tensor,
    ball_x_range: tuple[float, float],
    ball_y_range: tuple[float, float],
    target_distance_range: tuple[float, float],
    target_angle_ranges_deg: tuple[tuple[float, float], ...],
    stage_steps: tuple[int, ...] = (250_000, 750_000, 1_500_000),
    curriculum_stage: int = -1,
    ball_height: float = 0.105,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> None:
    """Reset a front ball and a curriculum-sampled 360-degree target.

    The desired robot state is a ball-relative line segment rather than a
    sampled point: behind the ball along the target direction, 0.15--0.35 m
    from the ball. The ball itself is always sampled at positive robot-frame x,
    so the first observation is always a front-ball scenario.
    """

    robot = _robot(env, robot_cfg)
    ball = _ball(env, ball_cfg)
    if env_ids is None:
        env_ids = torch.arange(env.num_envs, device=env.device)
    count = len(env_ids)
    stage = _stage_index(env, stage_steps, len(target_angle_ranges_deg), curriculum_stage)

    local = torch.zeros(count, 3, device=env.device)
    local[:, 0] = torch.empty(count, device=env.device).uniform_(*ball_x_range)
    local[:, 1] = torch.empty(count, device=env.device).uniform_(*ball_y_range)
    local[:, 2] = ball_height

    robot_yaw = yaw_quat(robot.data.root_quat_w[env_ids])
    w, z = robot_yaw[:, 0], robot_yaw[:, 3]
    cos_yaw = 1.0 - 2.0 * z.square()
    sin_yaw = 2.0 * w * z
    offset_w = local.clone()
    offset_w[:, 0] = cos_yaw * local[:, 0] - sin_yaw * local[:, 1]
    offset_w[:, 1] = sin_yaw * local[:, 0] + cos_yaw * local[:, 1]

    pose = ball.data.default_root_state[env_ids, :7].clone()
    pose[:, :3] = robot.data.root_pos_w[env_ids] + offset_w
    pose[:, 2] = env.scene.env_origins[env_ids, 2] + ball_height
    velocity = torch.zeros(count, 6, device=env.device)
    ball.write_root_pose_to_sim(pose, env_ids=env_ids)
    ball.write_root_velocity_to_sim(velocity, env_ids=env_ids)

    if not hasattr(env, "_adjust_ball_start_xy"):
        env._adjust_ball_start_xy = torch.zeros(env.num_envs, 2, device=env.device)
    env._adjust_ball_start_xy[env_ids] = pose[:, :2]

    relative_angle = torch.empty(count, device=env.device).uniform_(*target_angle_ranges_deg[stage])
    relative_angle = relative_angle * math.pi / 180.0
    initial_yaw = torch.atan2(2.0 * robot_yaw[:, 0] * robot_yaw[:, 3], 1.0 - 2.0 * robot_yaw[:, 3].square())
    target_angle = initial_yaw + relative_angle
    target_distance = torch.empty(count, device=env.device).uniform_(*target_distance_range)
    direction_w = torch.stack((torch.cos(target_angle), torch.sin(target_angle)), dim=1)
    target_w = pose[:, :2] + target_distance.unsqueeze(1) * direction_w

    if not hasattr(env, "_adjust_target_w"):
        env._adjust_target_w = torch.zeros(env.num_envs, 2, device=env.device)
        env._adjust_prev_alignment_error = torch.full((env.num_envs,), torch.nan, device=env.device)
        env._adjust_stable_time = torch.zeros(env.num_envs, device=env.device)
        env._adjust_alignment_achieved = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
    env._adjust_target_w[env_ids] = target_w
    env._adjust_prev_alignment_error[env_ids] = torch.nan
    env._adjust_stable_time[env_ids] = 0.0
    env._adjust_alignment_achieved[env_ids] = False
    env._adjust_curriculum_stage = stage


def alignment_line_band_error(
    env: ManagerBasedRLEnv,
    minimum_distance: float = 0.15,
    maximum_distance: float = 0.35,
) -> torch.Tensor:
    """Distance to the target->ball line segment behind the ball."""

    robot = env.scene["robot"]
    ball = env.scene["ball"]
    direction_w = _target_direction_w(env)
    robot_from_ball = robot.data.root_pos_w[:, :2] - ball.data.root_pos_w[:, :2]
    behind_distance = torch.sum(robot_from_ball * (-direction_w), dim=1)
    lateral_distance = torch.abs(
        robot_from_ball[:, 0] * direction_w[:, 1]
        - robot_from_ball[:, 1] * direction_w[:, 0]
    )
    distance_band_error = torch.where(
        behind_distance < minimum_distance,
        minimum_distance - behind_distance,
        (behind_distance - maximum_distance).clamp_min(0.0),
    )
    return torch.sqrt(lateral_distance.square() + distance_band_error.square())


def alignment_position_error(env: ManagerBasedRLEnv) -> torch.Tensor:
    return alignment_line_band_error(env)


def alignment_position_reward(
    env: ManagerBasedRLEnv,
    std: float = 0.12,
) -> torch.Tensor:
    error = alignment_position_error(env)
    return torch.exp(-error.square() / (std * std))


def alignment_position_progress(
    env: ManagerBasedRLEnv,
    max_progress_per_step: float = 0.04,
) -> torch.Tensor:
    current = alignment_position_error(env)
    if not hasattr(env, "_adjust_prev_alignment_error"):
        env._adjust_prev_alignment_error = current.detach().clone()
        return torch.zeros_like(current)
    previous = env._adjust_prev_alignment_error
    valid = torch.isfinite(previous)
    progress = torch.where(valid, previous - current, torch.zeros_like(current))
    env._adjust_prev_alignment_error.copy_(current)
    return (progress / max_progress_per_step).clamp(-1.0, 1.0)


def alignment_time_penalty(env: ManagerBasedRLEnv) -> torch.Tensor:
    return torch.ones(env.num_envs, device=env.device)


def ball_motion_penalty(
    env: ManagerBasedRLEnv,
    speed_scale: float = 0.08,
    displacement_scale: float = 0.02,
) -> torch.Tensor:
    speed = ball_speed(env)
    displacement = ball_displacement(env)
    return (speed / speed_scale + displacement / displacement_scale).clamp(0.0, 10.0)


def feet_ball_proximity_penalty(
    env: ManagerBasedRLEnv,
    safe_distance: float = 0.20,
    asset_cfg: SceneEntityCfg = SceneEntityCfg(
        "robot", body_names=["left_foot_link", "right_foot_link"], preserve_order=True
    ),
) -> torch.Tensor:
    robot = _robot(env, asset_cfg)
    ball = env.scene["ball"]
    feet = robot.data.body_pos_w[:, asset_cfg.body_ids]
    distance = torch.norm(feet - ball.data.root_pos_w[:, None, :], dim=2).amin(dim=1)
    return ((safe_distance - distance).clamp_min(0.0) / safe_distance).square()


def alignment_success(
    env: ManagerBasedRLEnv,
    position_tolerance: float = 0.06,
    ball_speed_tolerance: float = 0.05,
    ball_displacement_tolerance: float = 0.02,
    stable_time: float = 0.12,
) -> torch.Tensor:
    position_ready = alignment_position_error(env) <= position_tolerance
    ball_ready = (ball_speed(env) <= ball_speed_tolerance) & (
        ball_displacement(env) <= ball_displacement_tolerance
    )
    ready = position_ready & ball_ready
    if not hasattr(env, "_adjust_stable_time"):
        env._adjust_stable_time = torch.zeros(env.num_envs, device=env.device)
        env._adjust_alignment_achieved = torch.zeros(
            env.num_envs, dtype=torch.bool, device=env.device
        )
    env._adjust_stable_time += ready.float() * env.step_dt
    env._adjust_stable_time[~ready] = 0.0
    env._adjust_alignment_achieved |= env._adjust_stable_time >= stable_time
    return env._adjust_alignment_achieved


def ball_motion_termination(
    env: ManagerBasedRLEnv,
    speed_threshold: float = 0.08,
    displacement_threshold: float = 0.02,
) -> torch.Tensor:
    """Fail the alignment episode when contact causes meaningful ball motion."""

    return (ball_speed(env) > speed_threshold) | (
        ball_displacement(env) > displacement_threshold
    )
