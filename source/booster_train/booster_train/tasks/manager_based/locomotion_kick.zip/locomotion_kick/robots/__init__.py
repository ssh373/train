"""Robot variants."""
