"""K1 variants."""
