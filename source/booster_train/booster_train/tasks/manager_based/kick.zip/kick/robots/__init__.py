"""Robot-specific kicking environments."""

