# K1 ball kicking

This package ports the direct-joint K1 kicking task from the legacy Isaac Gym
environment into the repository's Isaac Lab manager-based task layout.

Shared RSL-RL actor-critic and PPO settings live under `kick/agents`; each robot
task keeps only its task-specific runner override in its local `ppo_cfg.py`.

## Environments

- `Booster-K1-Kick_001-v0`: 4096-environment training configuration.
- `Booster-K1-Kick_001-Play-v0`: 32-environment play configuration without pushes.

## Run

From an Isaac Lab shell with this extension installed:

```bash
python scripts/rsl_rl/train.py --task Booster-K1-Kick_001-v0 --headless
python scripts/rsl_rl/play.py --task Booster-K1-Kick_001-Play-v0 --num_envs 1
```

The actor observation has 49 values in this order: projected gravity (3), base
angular velocity (3), robot-frame ball XY position (2), robot-frame kick-target XY
position (2), visibility/age/confidence (3), 12 joint position errors, 12 joint
velocities, and 12 previous actions. Ball velocity is intentionally excluded from
the actor input; it remains available to rewards, terminations, and the critic. The
critic additionally receives uncorrupted
robot, ball, foot, and joint state.

The first port uses exact simulator ball state with observation noise. Visibility
and confidence are therefore `1` and age is `0`; the three channels intentionally
preserve the legacy deployment interface so a camera dropout/last-seen model can be
added without changing the policy shape.

The kicking foot is not fixed and is selected from kick geometry. If the target is
left of the ball in the robot frame, the right foot is preferred; if it is right of
the ball, the left foot is preferred. Within a 3 cm lateral deadband either foot is
accepted. This supports inside-foot directional kicks instead of simply matching
the foot to the side on which the ball spawned.

The selected side is latched at reset. At the instant ball speed rises sharply,
the closest foot is treated as the foot that kicked: a correct-foot event receives
`+8`, a wrong-foot event receives `-8`, and approaching a stationary ball with the
non-selected foot receives an additional proximity penalty.

RSL-RL data augmentation mirrors every policy/critic sample and action across the
robot sagittal plane. Ball and target y coordinates, vector signs, feet, and all
left/right leg joints are reflected consistently, preventing a one-foot policy from
receiving more training data than its mirrored counterpart.

The episode is phase-aware. Before contact, an upright and quiet base is rewarded.
After the ball exceeds 0.2 m/s, a recovery reward favors low body/joint velocity,
small tilt, and return toward the default stance. A successful kick is not allowed
to terminate immediately: the robot must recover for at least 0.8 s and satisfy
base-speed and tilt limits, so the policy learns a stable follow-through and landing.

Actions use K1's torque-aware joint-specific scales (roughly 0.12--0.35 rad), and
the initial policy noise standard deviation is 0.5. These limits prevent the first
iterations from applying +/-1 rad offsets to every leg joint and immediately falling.

The simulated ball uses nominal Size 4 association-football dimensions: 0.103 m
radius (0.206 m diameter) and 0.37 kg mass. Its reset center height is 0.105 m.

Standing rewards are deliberately small. Foot-to-ball distance progress supplies a
dense approach signal, waiting carries a strong quadratic penalty, and an episode
terminates if the ball has not started moving within 3 s. This prevents the stable
standing pose from becoming more profitable than attempting a kick.

Each environment places the robot near its origin and samples the ball 0.20--0.35 m
forward and +/-0.15 m laterally in the robot frame. On every reset, the target is
placed 4.0 m from the robot at a uniformly sampled heading from -60 to +60 degrees
relative to its initial forward direction. Success requires entering a 0.25 m target radius
with trajectory-direction cosine above 0.98 and ball speed below 2.5 m/s. Target-distance
reward, lateral-velocity penalty, and overspeed penalty favor accurate placement
over a merely powerful kick. The nominal base-height target is 0.55 m.
