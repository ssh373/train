"""Observations, rewards, events and terminations for K1 ball kicking."""

from __future__ import annotations

import torch

from isaaclab.assets import Articulation, RigidObject
from isaaclab.envs import ManagerBasedEnv, ManagerBasedRLEnv
from isaaclab.managers import SceneEntityCfg
from isaaclab.utils.math import quat_apply_inverse, yaw_quat


def _kick_target_w(env: ManagerBasedEnv, fallback_xy: tuple[float, float]) -> torch.Tensor:
    """Return the per-environment target, or a fixed local fallback before reset."""
    if hasattr(env, "_kick_target_w"):
        return env._kick_target_w
    return env.scene.env_origins[:, :2] + torch.tensor(fallback_xy, device=env.device)


def ball_pos_b(
    env: ManagerBasedEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Ball position relative to the robot, expressed in the robot yaw frame."""
    robot: Articulation = env.scene[robot_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    delta_w = ball.data.root_pos_w - robot.data.root_pos_w
    return quat_apply_inverse(yaw_quat(robot.data.root_quat_w), delta_w)[:, :2]


def ball_vel_b(
    env: ManagerBasedEnv,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Ball velocity relative to the robot, expressed in the robot yaw frame."""
    robot: Articulation = env.scene[robot_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    delta_w = ball.data.root_lin_vel_w - robot.data.root_lin_vel_w
    return quat_apply_inverse(yaw_quat(robot.data.root_quat_w), delta_w)[:, :2]


def kick_target_pos_b(
    env: ManagerBasedEnv,
    target_xy: tuple[float, float] = (4.0, 0.0),
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
) -> torch.Tensor:
    """Kick target relative to the robot, expressed in the robot yaw frame."""
    robot: Articulation = env.scene[robot_cfg.name]
    target_w = torch.zeros(env.num_envs, 3, device=env.device)
    target_w[:, :2] = _kick_target_w(env, target_xy)
    target_w[:, 2] = robot.data.root_pos_w[:, 2]
    delta_w = target_w - robot.data.root_pos_w
    return quat_apply_inverse(yaw_quat(robot.data.root_quat_w), delta_w)[:, :2]


def ball_visible(env: ManagerBasedEnv) -> torch.Tensor:
    """Visibility flag reserved for the deployment-compatible perception interface."""
    return torch.ones(env.num_envs, 1, device=env.device)


def ball_time_since_seen(env: ManagerBasedEnv) -> torch.Tensor:
    """Age of the exact simulator observation (zero while no dropout model is enabled)."""
    return torch.zeros(env.num_envs, 1, device=env.device)


def ball_confidence(env: ManagerBasedEnv) -> torch.Tensor:
    """Confidence of the exact simulator observation."""
    return torch.ones(env.num_envs, 1, device=env.device)


def ball_pos_w(env: ManagerBasedEnv, ball_cfg: SceneEntityCfg = SceneEntityCfg("ball")) -> torch.Tensor:
    ball: RigidObject = env.scene[ball_cfg.name]
    return ball.data.root_pos_w - env.scene.env_origins


def ball_vel_w(env: ManagerBasedEnv, ball_cfg: SceneEntityCfg = SceneEntityCfg("ball")) -> torch.Tensor:
    ball: RigidObject = env.scene[ball_cfg.name]
    return ball.data.root_lin_vel_w


def feet_pos_b(
    env: ManagerBasedEnv,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot", body_names=["left_foot_link", "right_foot_link"]),
) -> torch.Tensor:
    robot: Articulation = env.scene[asset_cfg.name]
    delta_w = robot.data.body_pos_w[:, asset_cfg.body_ids] - robot.data.root_pos_w[:, None, :]
    quat = yaw_quat(robot.data.root_quat_w)[:, None, :].expand(-1, len(asset_cfg.body_ids), -1)
    return quat_apply_inverse(quat.reshape(-1, 4), delta_w.reshape(-1, 3)).reshape(env.num_envs, -1)


def reset_ball_in_front(
    env: ManagerBasedEnv,
    env_ids: torch.Tensor,
    x_range: tuple[float, float],
    y_range: tuple[float, float],
    height: float = 0.055,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
):
    """Reset the ball at a randomized position in front of each robot."""
    robot: Articulation = env.scene[robot_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    count = len(env_ids)
    local = torch.zeros(count, 3, device=env.device)
    local[:, 0].uniform_(*x_range)
    local[:, 1].uniform_(*y_range)
    local[:, 2] = height

    robot_quat = yaw_quat(robot.data.root_quat_w[env_ids])
    # Rotate only x/y without depending on a quaternion helper's broadcasting rules.
    w, z = robot_quat[:, 0], robot_quat[:, 3]
    cos_yaw = 1.0 - 2.0 * z.square()
    sin_yaw = 2.0 * w * z
    offset_w = local.clone()
    offset_w[:, 0] = cos_yaw * local[:, 0] - sin_yaw * local[:, 1]
    offset_w[:, 1] = sin_yaw * local[:, 0] + cos_yaw * local[:, 1]

    pose = ball.data.default_root_state[env_ids, :7].clone()
    pose[:, :3] = robot.data.root_pos_w[env_ids] + offset_w
    pose[:, 2] = env.scene.env_origins[env_ids, 2] + height
    velocity = torch.zeros(count, 6, device=env.device)
    ball.write_root_pose_to_sim(pose, env_ids=env_ids)
    ball.write_root_velocity_to_sim(velocity, env_ids=env_ids)

    if not hasattr(env, "_kick_preferred_foot"):
        env._kick_preferred_foot = torch.zeros(env.num_envs, dtype=torch.long, device=env.device)
    # Body-frame +y is left (index 0), -y is right (index 1).
    side_preference = torch.where(local[:, 1] >= 0.0, 0, 1)
    env._kick_preferred_foot[env_ids] = torch.where(local[:, 1].abs() <= 0.03, -1, side_preference)

    if not hasattr(env, "_kick_ball_start_xy"):
        env._kick_ball_start_xy = torch.zeros(env.num_envs, 2, device=env.device)
    env._kick_ball_start_xy[env_ids] = pose[:, :2]

    if hasattr(env, "_kick_prev_ball_vel"):
        env._kick_prev_ball_vel[env_ids] = 0.0
    if hasattr(env, "_kick_happened"):
        env._kick_happened[env_ids] = False
        env._kick_recovery_time[env_ids] = 0.0
    if hasattr(env, "_kick_target_achieved"):
        env._kick_target_achieved[env_ids] = False
    if hasattr(env, "_kick_prev_selected_foot_distance"):
        env._kick_prev_selected_foot_distance[env_ids] = torch.nan
    if hasattr(env, "_kick_prev_ball_speed_for_foot"):
        env._kick_prev_ball_speed_for_foot[env_ids] = 0.0


def reset_kick_target(
    env: ManagerBasedEnv,
    env_ids: torch.Tensor,
    distance_range: tuple[float, float] = (4.0, 4.0),
    angle_range_deg: tuple[float, float] = (-60.0, 60.0),
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
):
    """Sample a target distance and angle relative to the robot's initial heading."""
    robot: Articulation = env.scene[robot_cfg.name]
    count = len(env_ids)
    if not hasattr(env, "_kick_target_w"):
        env._kick_target_w = torch.zeros(env.num_envs, 2, device=env.device)

    distance = torch.empty(count, device=env.device).uniform_(*distance_range)
    relative_angle = torch.empty(count, device=env.device).uniform_(*angle_range_deg) * torch.pi / 180.0
    q = yaw_quat(robot.data.root_quat_w[env_ids])
    robot_yaw = torch.atan2(2.0 * q[:, 0] * q[:, 3], 1.0 - 2.0 * q[:, 3].square())
    world_angle = robot_yaw + relative_angle
    env._kick_target_w[env_ids, 0] = robot.data.root_pos_w[env_ids, 0] + distance * torch.cos(world_angle)
    env._kick_target_w[env_ids, 1] = robot.data.root_pos_w[env_ids, 1] + distance * torch.sin(world_angle)

    # Choose the inside-foot geometry from ball -> target, not merely ball side.
    # A target left of the ball is struck with the right foot and vice versa.
    ball: RigidObject = env.scene[ball_cfg.name]
    direction_w = torch.zeros(count, 3, device=env.device)
    direction_w[:, :2] = env._kick_target_w[env_ids] - ball.data.root_pos_w[env_ids, :2]
    direction_b = quat_apply_inverse(yaw_quat(robot.data.root_quat_w[env_ids]), direction_w)
    lateral = direction_b[:, 1]
    preferred = torch.where(lateral > 0.03, 1, 0)
    preferred = torch.where(lateral < -0.03, 0, preferred)
    env._kick_preferred_foot[env_ids] = torch.where(lateral.abs() <= 0.03, -1, preferred)


def survival(env: ManagerBasedRLEnv) -> torch.Tensor:
    return torch.ones(env.num_envs, device=env.device)


def stationary_base_xy(env: ManagerBasedRLEnv, std: float, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")):
    robot: Articulation = env.scene[asset_cfg.name]
    return torch.exp(-torch.sum(robot.data.root_lin_vel_b[:, :2].square(), dim=1) / (std * std))


def stationary_base_yaw(env: ManagerBasedRLEnv, std: float, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")):
    robot: Articulation = env.scene[asset_cfg.name]
    return torch.exp(-robot.data.root_ang_vel_b[:, 2].square() / (std * std))


def ball_velocity_to_target(
    env: ManagerBasedRLEnv,
    target_xy: tuple[float, float] = (4.0, 0.0),
    decay_distance: float = 4.0,
    max_reward: float = 10.0,
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    ball: RigidObject = env.scene[ball_cfg.name]
    target_w = _kick_target_w(env, target_xy)
    direction = target_w - ball.data.root_pos_w[:, :2]
    direction = direction / torch.norm(direction, dim=1, keepdim=True).clamp_min(1.0e-6)
    forward_speed = torch.sum(ball.data.root_lin_vel_w[:, :2] * direction, dim=1).clamp_min(0.0)
    # Spatial decay preserves the legacy intent without requiring a stateful moving-time buffer.
    distance_from_origin = torch.norm(ball.data.root_pos_w[:, :2] - env.scene.env_origins[:, :2], dim=1)
    return (forward_speed * torch.exp(-distance_from_origin / decay_distance)).clamp_max(max_reward)


def ball_target_accuracy(
    env: ManagerBasedRLEnv,
    target_xy: tuple[float, float] = (4.0, 0.0),
    std: float = 0.5,
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Reward the ball for approaching the actual target point."""
    ball: RigidObject = env.scene[ball_cfg.name]
    target_w = _kick_target_w(env, target_xy)
    distance = torch.norm(ball.data.root_pos_w[:, :2] - target_w, dim=1)
    return torch.exp(-distance.square() / (std * std))


def ball_lateral_velocity(
    env: ManagerBasedRLEnv,
    target_xy: tuple[float, float] = (4.0, 0.0),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Penalize velocity perpendicular to the ball-to-target direction."""
    ball: RigidObject = env.scene[ball_cfg.name]
    target_w = _kick_target_w(env, target_xy)
    direction = target_w - ball.data.root_pos_w[:, :2]
    direction = direction / torch.norm(direction, dim=1, keepdim=True).clamp_min(1.0e-6)
    velocity = ball.data.root_lin_vel_w[:, :2]
    forward = torch.sum(velocity * direction, dim=1, keepdim=True) * direction
    return torch.sum((velocity - forward).square(), dim=1)


def ball_overspeed(
    env: ManagerBasedRLEnv,
    max_speed: float = 2.5,
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Penalize only the portion of ball speed above the useful range."""
    ball: RigidObject = env.scene[ball_cfg.name]
    excess = (torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1) - max_speed).clamp_min(0.0)
    return excess.square()


def kicking_foot_approach_ball(
    env: ManagerBasedRLEnv,
    proximity_std: float = 0.1,
    stationary_speed: float = 0.1,
    velocity_weight: float = 0.3,
    center_deadband: float = 0.03,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot", body_names=["left_foot_link", "right_foot_link"]),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Reward the foot selected from the ball's lateral position.

    Positive robot-frame y selects the left foot and negative y selects the right
    foot. Inside a small center deadband, the physically nearer foot is selected.
    """
    robot: Articulation = env.scene[asset_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    foot_pos_all = robot.data.body_pos_w[:, asset_cfg.body_ids]
    foot_vel_all = robot.data.body_lin_vel_w[:, asset_cfg.body_ids]
    distances = torch.norm(foot_pos_all - ball.data.root_pos_w[:, None, :], dim=2)

    ball_local_y = ball_pos_b(env, ball_cfg=ball_cfg)[:, 1]
    preferred_idx = getattr(env, "_kick_preferred_foot", torch.where(ball_local_y >= 0.0, 0, 1))
    nearest_idx = torch.argmin(distances, dim=1)
    selected_idx = torch.where(ball_local_y.abs() <= center_deadband, nearest_idx, preferred_idx)
    env_ids = torch.arange(env.num_envs, device=env.device)
    foot_pos = foot_pos_all[env_ids, selected_idx]
    foot_vel = foot_vel_all[env_ids, selected_idx]
    to_ball = ball.data.root_pos_w - foot_pos
    distance = torch.norm(to_ball, dim=1)
    direction = to_ball / distance.unsqueeze(1).clamp_min(1.0e-6)
    proximity = torch.exp(-distance / proximity_std)
    closing_speed = torch.sum(foot_vel * direction, dim=1).clamp_min(0.0)
    stationary = (torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1) < stationary_speed).float()
    return ((1.0 - velocity_weight) * proximity + velocity_weight * closing_speed) * stationary


def kicking_foot_approach_progress(
    env: ManagerBasedRLEnv,
    center_deadband: float = 0.03,
    max_progress_per_step: float = 0.04,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot", body_names=["left_foot_link", "right_foot_link"]),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Dense reward for reducing the selected foot-to-ball distance each step."""
    robot: Articulation = env.scene[asset_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    feet = robot.data.body_pos_w[:, asset_cfg.body_ids]
    distances = torch.norm(feet - ball.data.root_pos_w[:, None, :], dim=2)
    ball_y = ball_pos_b(env, ball_cfg=ball_cfg)[:, 1]
    preferred = getattr(env, "_kick_preferred_foot", torch.where(ball_y >= 0.0, 0, 1))
    nearest = torch.argmin(distances, dim=1)
    selected = torch.where(ball_y.abs() <= center_deadband, nearest, preferred)
    current = distances[torch.arange(env.num_envs, device=env.device), selected]

    if not hasattr(env, "_kick_prev_selected_foot_distance"):
        env._kick_prev_selected_foot_distance = current.detach().clone()
        return torch.zeros_like(current)
    previous = env._kick_prev_selected_foot_distance
    initialized = torch.isfinite(previous)
    progress = torch.where(initialized, previous - current, torch.zeros_like(current))
    progress = progress.clamp(min=-max_progress_per_step, max=max_progress_per_step)
    env._kick_prev_selected_foot_distance.copy_(current)
    ball_stationary = (torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1) < 0.1).float()
    return progress / max_progress_per_step * ball_stationary


def preferred_foot_kick_event(
    env: ManagerBasedRLEnv,
    speed_increase_threshold: float = 0.08,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot", body_names=["left_foot_link", "right_foot_link"]),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Return +1 for a preferred-foot kick event and -1 for a wrong-foot event."""
    robot: Articulation = env.scene[asset_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    speed = torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1)
    if not hasattr(env, "_kick_prev_ball_speed_for_foot"):
        env._kick_prev_ball_speed_for_foot = speed.detach().clone()
        return torch.zeros_like(speed)
    speed_increase = speed - env._kick_prev_ball_speed_for_foot
    env._kick_prev_ball_speed_for_foot.copy_(speed)
    event = speed_increase > speed_increase_threshold

    feet = robot.data.body_pos_w[:, asset_cfg.body_ids]
    actual_foot = torch.argmin(torch.norm(feet - ball.data.root_pos_w[:, None, :], dim=2), dim=1)
    ball_y = ball_pos_b(env, ball_cfg=ball_cfg)[:, 1]
    preferred = getattr(env, "_kick_preferred_foot", torch.where(ball_y >= 0.0, 0, 1))
    correct = (preferred < 0) | (actual_foot == preferred)
    signed = torch.where(correct, torch.ones_like(speed), -torch.ones_like(speed))
    return signed * event.float()


def wrong_foot_proximity(
    env: ManagerBasedRLEnv,
    proximity_std: float = 0.15,
    asset_cfg: SceneEntityCfg = SceneEntityCfg("robot", body_names=["left_foot_link", "right_foot_link"]),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Penalize bringing the non-selected foot close to a stationary ball."""
    robot: Articulation = env.scene[asset_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    feet = robot.data.body_pos_w[:, asset_cfg.body_ids]
    ball_y = ball_pos_b(env, ball_cfg=ball_cfg)[:, 1]
    preferred = getattr(env, "_kick_preferred_foot", torch.where(ball_y >= 0.0, 0, 1))
    has_preference = preferred >= 0
    wrong = (1 - preferred).clamp(min=0, max=1)
    distance = torch.norm(feet[torch.arange(env.num_envs, device=env.device), wrong] - ball.data.root_pos_w, dim=1)
    stationary = (torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1) < 0.1).float()
    return torch.exp(-distance / proximity_std) * stationary * has_preference.float()


def body_alignment_to_ball_and_target(
    env: ManagerBasedRLEnv,
    target_xy: tuple[float, float] = (4.0, 0.0),
    std: float = 0.5,
    ball_weight: float = 0.6,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    robot: Articulation = env.scene[robot_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    forward = torch.zeros(env.num_envs, 3, device=env.device)
    forward[:, 0] = 1.0
    # World forward vector using yaw quaternion.
    q = yaw_quat(robot.data.root_quat_w)
    forward_w = torch.stack((1.0 - 2.0 * q[:, 3].square(), 2.0 * q[:, 0] * q[:, 3]), dim=1)
    to_ball = ball.data.root_pos_w[:, :2] - robot.data.root_pos_w[:, :2]
    to_ball = to_ball / torch.norm(to_ball, dim=1, keepdim=True).clamp_min(1.0e-6)
    target_w = _kick_target_w(env, target_xy)
    to_target = target_w - robot.data.root_pos_w[:, :2]
    to_target = to_target / torch.norm(to_target, dim=1, keepdim=True).clamp_min(1.0e-6)
    ball_score = torch.exp((torch.sum(forward_w * to_ball, dim=1) - 1.0) / std)
    target_score = torch.exp((torch.sum(forward_w * to_target, dim=1) - 1.0) / std)
    return ball_weight * ball_score + (1.0 - ball_weight) * target_score


def ball_acceleration_to_target(
    env: ManagerBasedRLEnv,
    target_xy: tuple[float, float] = (4.0, 0.0),
    scale: float = 80.0,
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    ball: RigidObject = env.scene[ball_cfg.name]
    velocity = ball.data.root_lin_vel_w[:, :2]
    if not hasattr(env, "_kick_prev_ball_vel"):
        env._kick_prev_ball_vel = velocity.detach().clone()
    acceleration = (velocity - env._kick_prev_ball_vel) / env.step_dt
    env._kick_prev_ball_vel.copy_(velocity)
    target_w = _kick_target_w(env, target_xy)
    direction = target_w - ball.data.root_pos_w[:, :2]
    direction = direction / torch.norm(direction, dim=1, keepdim=True).clamp_min(1.0e-6)
    forward = torch.sum(acceleration * direction, dim=1)
    lateral = torch.norm(acceleration - forward.unsqueeze(1) * direction, dim=1)
    return torch.tanh((forward - lateral).clamp_min(0.0) / scale)


def waiting_penalty(env: ManagerBasedRLEnv, ball_cfg: SceneEntityCfg = SceneEntityCfg("ball")) -> torch.Tensor:
    ball: RigidObject = env.scene[ball_cfg.name]
    progress = env.episode_length_buf.float() / env.max_episode_length
    stationary = (torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1) < 0.1).float()
    return progress.square() * stationary


def pre_kick_stability(
    env: ManagerBasedRLEnv,
    ball_speed_threshold: float = 0.15,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Reward a quiet, upright base while the ball has not yet been kicked."""
    robot: Articulation = env.scene[robot_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    before_kick = (torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1) < ball_speed_threshold).float()
    lin_error = torch.sum(robot.data.root_lin_vel_b.square(), dim=1)
    ang_error = torch.sum(robot.data.root_ang_vel_b.square(), dim=1)
    tilt_error = torch.sum(robot.data.projected_gravity_b[:, :2].square(), dim=1)
    return torch.exp(-2.0 * lin_error - 0.5 * ang_error - 8.0 * tilt_error) * before_kick


def post_kick_recovery(
    env: ManagerBasedRLEnv,
    kick_speed_threshold: float = 0.2,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """Track the post-kick phase and reward settling into a stable default pose."""
    robot: Articulation = env.scene[robot_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    if not hasattr(env, "_kick_happened"):
        env._kick_happened = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
        env._kick_recovery_time = torch.zeros(env.num_envs, device=env.device)

    env._kick_happened |= torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1) > kick_speed_threshold
    env._kick_recovery_time += env._kick_happened.float() * env.step_dt

    joint_error = torch.mean((robot.data.joint_pos - robot.data.default_joint_pos).square(), dim=1)
    joint_speed = torch.mean(robot.data.joint_vel.square(), dim=1)
    base_lin = torch.sum(robot.data.root_lin_vel_b.square(), dim=1)
    base_ang = torch.sum(robot.data.root_ang_vel_b.square(), dim=1)
    tilt = torch.sum(robot.data.projected_gravity_b[:, :2].square(), dim=1)
    stability = torch.exp(
        -4.0 * joint_error - 0.05 * joint_speed - 2.0 * base_lin - 0.5 * base_ang - 10.0 * tilt
    )
    return stability * env._kick_happened.float()


def hip_roll_spread(env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg) -> torch.Tensor:
    robot: Articulation = env.scene[asset_cfg.name]
    return torch.sum(robot.data.joint_pos[:, asset_cfg.joint_ids].square(), dim=1)


def body_twist(env: ManagerBasedRLEnv, asset_cfg: SceneEntityCfg = SceneEntityCfg("robot")) -> torch.Tensor:
    robot: Articulation = env.scene[asset_cfg.name]
    return robot.data.root_ang_vel_b[:, 2].square()


def ball_success(
    env: ManagerBasedRLEnv,
    target_xy: tuple[float, float] = (4.0, 0.0),
    target_radius: float = 0.25,
    min_direction_score: float = 0.98,
    max_speed: float = 2.5,
    recovery_time: float = 0.8,
    max_base_speed: float = 0.35,
    max_tilt: float = 0.2,
    robot_cfg: SceneEntityCfg = SceneEntityCfg("robot"),
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    robot: Articulation = env.scene[robot_cfg.name]
    ball: RigidObject = env.scene[ball_cfg.name]
    if hasattr(env, "_kick_ball_start_xy"):
        relative_pos = ball.data.root_pos_w[:, :2] - env._kick_ball_start_xy
    else:
        relative_pos = ball.data.root_pos_w[:, :2] - env.scene.env_origins[:, :2]
    target_w = _kick_target_w(env, target_xy)
    start_to_target = target_w - getattr(env, "_kick_ball_start_xy", env.scene.env_origins[:, :2])
    target_dir = start_to_target / torch.norm(start_to_target, dim=1, keepdim=True).clamp_min(1.0e-6)
    target_distance = torch.norm(ball.data.root_pos_w[:, :2] - target_w, dim=1)
    velocity = ball.data.root_lin_vel_w[:, :2]
    speed = torch.norm(velocity, dim=1)
    travel = torch.norm(relative_pos, dim=1)
    direction_score = torch.sum(relative_pos * target_dir, dim=1) / travel.clamp_min(1.0e-6)
    kick_happened = getattr(env, "_kick_happened", torch.zeros(env.num_envs, dtype=torch.bool, device=env.device))
    if not hasattr(env, "_kick_target_achieved"):
        env._kick_target_achieved = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
    env._kick_target_achieved |= (
        (target_distance < target_radius)
        & (speed < max_speed)
        & (direction_score > min_direction_score)
        & kick_happened
    )

    recovered_long_enough = getattr(
        env, "_kick_recovery_time", torch.zeros(env.num_envs, device=env.device)
    ) >= recovery_time
    base_speed = torch.norm(robot.data.root_lin_vel_b, dim=1)
    tilt = torch.norm(robot.data.projected_gravity_b[:, :2], dim=1)
    stable = (base_speed < max_base_speed) & (tilt < max_tilt)
    return (
        env._kick_target_achieved
        & recovered_long_enough
        & stable
    )


def ball_too_far(env: ManagerBasedEnv, max_distance: float, ball_cfg: SceneEntityCfg = SceneEntityCfg("ball")):
    ball: RigidObject = env.scene[ball_cfg.name]
    return torch.norm(ball.data.root_pos_w[:, :2] - env.scene.env_origins[:, :2], dim=1) > max_distance


def ball_not_kicked_in_time(
    env: ManagerBasedRLEnv,
    time_limit: float = 3.0,
    movement_speed: float = 0.12,
    ball_cfg: SceneEntityCfg = SceneEntityCfg("ball"),
) -> torch.Tensor:
    """End unproductive episodes that keep collecting standing rewards."""
    ball: RigidObject = env.scene[ball_cfg.name]
    elapsed = env.episode_length_buf.float() * env.step_dt
    ball_moved = torch.norm(ball.data.root_lin_vel_w[:, :2], dim=1) > movement_speed
    kick_latched = getattr(env, "_kick_happened", torch.zeros(env.num_envs, dtype=torch.bool, device=env.device))
    return (elapsed > time_limit) & ~(ball_moved | kick_latched)
